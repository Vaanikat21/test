# FundChain – Database Layer

## MongoDB Setup

### Local Development
```bash
# Install MongoDB (Ubuntu/Debian)
sudo apt-get install -y mongodb

# Start MongoDB service
sudo systemctl start mongod
sudo systemctl enable mongod

# Verify it's running
mongosh --eval "db.runCommand({ connectionStatus: 1 })"
```

### MongoDB Atlas (Cloud – Free Tier)
1. Go to https://mongodb.com/cloud/atlas
2. Create a free M0 cluster
3. Add your IP to the allowlist
4. Create a database user
5. Copy the connection string and paste into `backend/.env` as `MONGO_URI`

---

## Schema: FundRequest

```
Collection: fundrequests

{
  _id:              ObjectId        -- MongoDB auto-ID
  clubName:         String          -- "Robotics Club"
  amount:           String          -- "0.05" (ETH, stored as string)
  amountWei:        String          -- "50000000000000000" (Wei)
  purpose:          String          -- "Annual hackathon equipment"
  walletAddress:    String          -- "0xabc..." (lowercase)
  status:           String          -- "pending" | "approved" | "released" | "rejected"
  
  -- On-chain references (filled after tx confirms)
  onChainRequestId: Number          -- ID from the smart contract mapping
  requestTxHash:    String          -- TX hash of requestFunds() call
  approveTxHash:    String          -- TX hash of approveRequest() call
  releaseTxHash:    String          -- TX hash of releaseFunds() call
  
  -- File upload
  receiptURL:       String          -- "/uploads/receipt-uuid.pdf"
  receiptFilename:  String          -- "receipt-uuid.pdf"
  
  -- Audit timestamps
  approvedAt:       Date
  releasedAt:       Date
  createdAt:        Date            -- Mongoose auto-timestamp
  updatedAt:        Date            -- Mongoose auto-timestamp
}
```

---

## Useful MongoDB Queries

```js
// Show all pending requests
db.fundrequests.find({ status: "pending" })

// Show requests by wallet
db.fundrequests.find({ walletAddress: "0xabc..." })

// Count by status
db.fundrequests.aggregate([
  { $group: { _id: "$status", count: { $sum: 1 } } }
])

// Find requests with on-chain IDs
db.fundrequests.find({ onChainRequestId: { $ne: null } })

// Total amount released
db.fundrequests.aggregate([
  { $match: { status: "released" } },
  { $group: { _id: null, total: { $sum: { $toDouble: "$amount" } } } }
])
```
