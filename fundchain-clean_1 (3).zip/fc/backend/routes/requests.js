const express = require("express");
const router  = express.Router();
const upload  = require("../middleware/upload");
const {
  createRequest,
  getRequests,
  getRequest,
  approveRequest,
  releaseFunds,
  uploadReceipt,
  getTransaction,
  getStats,
} = require("../controllers/requestController");

// ── Fund requests ─────────────────────────────────────────────────────
router.post  ("/request",        createRequest);
router.get   ("/requests",       getRequests);
router.get   ("/requests/:id",   getRequest);

// ── Admin actions ─────────────────────────────────────────────────────
router.patch ("/approve",        approveRequest);
router.patch ("/release",        releaseFunds);

// ── Receipt upload ────────────────────────────────────────────────────
router.post  ("/upload-receipt", upload.single("receipt"), uploadReceipt);

// ── Blockchain ────────────────────────────────────────────────────────
router.get   ("/tx/:hash",       getTransaction);
router.get   ("/stats",          getStats);

module.exports = router;
