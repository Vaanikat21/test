const { ethers } = require("ethers");
const Request    = require("../models/Request");
const path       = require("path");

// ── Lazy-load blockchain service ──────────────────────────────────────
let blockchainService = null;
function getBlockchain() {
  if (!blockchainService) {
    blockchainService = require("../config/blockchain");
  }
  return blockchainService;
}

// ── POST /api/request ─────────────────────────────────────────────────
exports.createRequest = async (req, res) => {
  try {
    const { clubName, amount, purpose, walletAddress } = req.body;

    if (!clubName || !amount || !purpose || !walletAddress)
      return res.status(400).json({ error: "All fields are required." });
    if (!ethers.isAddress(walletAddress))
      return res.status(400).json({ error: "Invalid wallet address." });
    if (isNaN(parseFloat(amount)) || parseFloat(amount) <= 0)
      return res.status(400).json({ error: "Amount must be a positive number." });

    const amountWei = ethers.parseEther(amount.toString()).toString();

    const fundRequest = new Request({
      clubName: clubName.trim(), amount: amount.toString(),
      amountWei, purpose: purpose.trim(),
      walletAddress: walletAddress.toLowerCase(),
    });

    const bc = getBlockchain();
    if (bc.isReady()) {
      try {
        const result = await bc.requestFunds(clubName, purpose, amountWei);
        fundRequest.requestTxHash    = result.txHash;
        fundRequest.onChainRequestId = result.onChainRequestId;
      } catch (chainErr) {
        console.warn("On-chain request failed:", chainErr.message);
      }
    }

    await fundRequest.save();
    res.status(201).json({ message: "Request submitted.", request: fundRequest, txHash: fundRequest.requestTxHash });
  } catch (err) {
    res.status(500).json({ error: "Failed to submit request.", details: err.message });
  }
};

// ── GET /api/requests ─────────────────────────────────────────────────
exports.getRequests = async (req, res) => {
  try {
    const { status, walletAddress } = req.query;
    const filter = {};
    if (status)        filter.status        = status;
    if (walletAddress) filter.walletAddress = walletAddress.toLowerCase();

    const requests = await Request.find(filter).sort({ createdAt: -1 });

    let contractStats = null;
    const bc = getBlockchain();
    if (bc.isReady()) {
      try { contractStats = await bc.getStats(); } catch (_) {}
    }

    res.json({ requests, contractStats });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch requests." });
  }
};

// ── GET /api/requests/:id ─────────────────────────────────────────────
exports.getRequest = async (req, res) => {
  try {
    const request = await Request.findById(req.params.id);
    if (!request) return res.status(404).json({ error: "Request not found." });
    res.json(request);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch request." });
  }
};

// ── PATCH /api/approve ────────────────────────────────────────────────
exports.approveRequest = async (req, res) => {
  try {
    const { requestId, adminSecret } = req.body;
    if (adminSecret !== process.env.ADMIN_SECRET)
      return res.status(403).json({ error: "Unauthorized." });

    const fundRequest = await Request.findById(requestId);
    if (!fundRequest)              return res.status(404).json({ error: "Request not found." });
    if (fundRequest.status !== "pending") return res.status(400).json({ error: `Already ${fundRequest.status}.` });

    let txHash = null;
    const bc = getBlockchain();
    if (bc.isReady() && fundRequest.onChainRequestId !== null) {
      const result = await bc.approveRequest(fundRequest.onChainRequestId);
      txHash = result.txHash;
    }

    fundRequest.status       = "approved";
    fundRequest.approveTxHash = txHash;
    fundRequest.approvedAt   = new Date();
    await fundRequest.save();

    res.json({ message: "Request approved.", request: fundRequest, txHash });
  } catch (err) {
    res.status(500).json({ error: "Failed to approve.", details: err.message });
  }
};

// ── PATCH /api/release ────────────────────────────────────────────────
exports.releaseFunds = async (req, res) => {
  try {
    const { requestId, adminSecret } = req.body;
    if (adminSecret !== process.env.ADMIN_SECRET)
      return res.status(403).json({ error: "Unauthorized." });

    const fundRequest = await Request.findById(requestId);
    if (!fundRequest)               return res.status(404).json({ error: "Request not found." });
    if (fundRequest.status !== "approved") return res.status(400).json({ error: "Must be approved first." });

    let txHash = null;
    const bc = getBlockchain();
    if (bc.isReady() && fundRequest.onChainRequestId !== null) {
      const result = await bc.releaseFunds(fundRequest.onChainRequestId);
      txHash = result.txHash;
    }

    fundRequest.status        = "released";
    fundRequest.releaseTxHash = txHash;
    fundRequest.releasedAt    = new Date();
    await fundRequest.save();

    res.json({ message: "Funds released.", request: fundRequest, txHash });
  } catch (err) {
    res.status(500).json({ error: "Failed to release.", details: err.message });
  }
};

// ── POST /api/upload-receipt ──────────────────────────────────────────
exports.uploadReceipt = async (req, res) => {
  try {
    const { requestId } = req.body;
    if (!req.file)   return res.status(400).json({ error: "No file uploaded." });
    if (!requestId)  return res.status(400).json({ error: "requestId is required." });

    const fundRequest = await Request.findById(requestId);
    if (!fundRequest) return res.status(404).json({ error: "Request not found." });

    fundRequest.receiptURL      = `/uploads/${req.file.filename}`;
    fundRequest.receiptFilename = req.file.filename;
    await fundRequest.save();

    res.json({ message: "Receipt uploaded.", receiptURL: fundRequest.receiptURL });
  } catch (err) {
    res.status(500).json({ error: "Upload failed.", details: err.message });
  }
};

// ── GET /api/tx/:hash ─────────────────────────────────────────────────
exports.getTransaction = async (req, res) => {
  try {
    const bc = getBlockchain();
    if (!bc.isReady()) return res.status(503).json({ error: "Blockchain unavailable." });
    const txData = await bc.getTransaction(req.params.hash);
    res.json(txData);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch transaction.", details: err.message });
  }
};

// ── GET /api/stats ────────────────────────────────────────────────────
exports.getStats = async (req, res) => {
  try {
    const dbStats = {
      total:    await Request.countDocuments(),
      pending:  await Request.countDocuments({ status: "pending"  }),
      approved: await Request.countDocuments({ status: "approved" }),
      released: await Request.countDocuments({ status: "released" }),
    };
    let contractStats = null;
    const bc = getBlockchain();
    if (bc.isReady()) {
      try { contractStats = await bc.getStats(); } catch (_) {}
    }
    res.json({ dbStats, contractStats });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch stats." });
  }
};
