const mongoose = require("mongoose");

async function connectDB() {
  const uri = process.env.MONGO_URI || "mongodb://localhost:27017/fundchain";
  try {
    await mongoose.connect(uri);
    console.log("✅ MongoDB connected:", mongoose.connection.host);
  } catch (err) {
    console.error("❌ MongoDB connection failed:", err.message);
    console.log("   Continuing without database — some features may not work.");
  }
}

module.exports = connectDB;
