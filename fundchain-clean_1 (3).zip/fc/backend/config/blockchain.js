const { ethers } = require("ethers");
const path       = require("path");
const fs         = require("fs");

let contractABI = [];
const abiPath   = path.join(__dirname, "./contractABI.json");
try {
  contractABI = JSON.parse(fs.readFileSync(abiPath, "utf8"));
} catch (_) {
  console.warn("⚠  contractABI.json not found. Deploy contract first.");
}

class BlockchainService {
  constructor() {
    this.provider  = null;
    this.signer    = null;
    this.contract  = null;
    this.initialized = false;
  }

  async init() {
    try {
      const rpcUrl          = process.env.RPC_URL          || "http://127.0.0.1:8545";
      const privateKey      = process.env.ADMIN_PRIVATE_KEY;
      const contractAddress = process.env.CONTRACT_ADDRESS;

      if (!privateKey || !contractAddress || contractAddress === "PASTE_CONTRACT_ADDRESS_HERE") {
        console.warn("⚠  CONTRACT_ADDRESS or ADMIN_PRIVATE_KEY missing. Blockchain disabled.");
        return false;
      }

      this.provider = new ethers.JsonRpcProvider(rpcUrl);
      this.signer   = new ethers.Wallet(privateKey, this.provider);
      this.contract = new ethers.Contract(contractAddress, contractABI, this.signer);

      const network = await this.provider.getNetwork();
      const balance = await this.provider.getBalance(this.signer.address);
      console.log(`✅ Blockchain connected — ${network.name} (chainId: ${network.chainId})`);
      console.log(`   Admin: ${this.signer.address}`);
      console.log(`   Balance: ${ethers.formatEther(balance)} ETH`);

      this.initialized = true;
      return true;
    } catch (err) {
      console.error("❌ Blockchain init failed:", err.message);
      return false;
    }
  }

  isReady() { return this.initialized && this.contract !== null; }

  async depositFunds(amountEth) {
    const tx      = await this.contract.depositFunds({ value: ethers.parseEther(amountEth) });
    const receipt = await tx.wait();
    return { txHash: tx.hash, blockNumber: receipt.blockNumber };
  }

  async requestFunds(clubName, purpose, amountWei) {
    const tx      = await this.contract.requestFunds(clubName, purpose, BigInt(amountWei));
    const receipt = await tx.wait();
    const event   = receipt.logs.map(log => { try { return this.contract.interface.parseLog(log); } catch { return null; } }).find(e => e && e.name === "FundRequested");
    return { txHash: tx.hash, blockNumber: receipt.blockNumber, onChainRequestId: event ? Number(event.args.requestId) : null };
  }

  async approveRequest(requestId) {
    const tx      = await this.contract.approveRequest(requestId);
    const receipt = await tx.wait();
    return { txHash: tx.hash, blockNumber: receipt.blockNumber };
  }

  async releaseFunds(requestId) {
    const tx      = await this.contract.releaseFunds(requestId);
    const receipt = await tx.wait();
    return { txHash: tx.hash, blockNumber: receipt.blockNumber };
  }

  async getStats() {
    const [balance, deposited, released, pending, total] = await this.contract.getContractStats();
    return {
      balanceEth:   ethers.formatEther(balance),
      depositedEth: ethers.formatEther(deposited),
      releasedEth:  ethers.formatEther(released),
      pendingCount: Number(pending),
      totalCount:   Number(total),
    };
  }

  async getTransaction(txHash) {
    const tx      = await this.provider.getTransaction(txHash);
    const receipt = await this.provider.getTransactionReceipt(txHash);
    const block   = await this.provider.getBlock(receipt.blockNumber);
    return {
      hash:        tx.hash,
      from:        tx.from,
      to:          tx.to,
      value:       ethers.formatEther(tx.value),
      blockNumber: receipt.blockNumber,
      status:      receipt.status === 1 ? "success" : "failed",
      gasUsed:     receipt.gasUsed.toString(),
      timestamp:   new Date(Number(block.timestamp) * 1000).toISOString(),
    };
  }
}

module.exports = new BlockchainService();
