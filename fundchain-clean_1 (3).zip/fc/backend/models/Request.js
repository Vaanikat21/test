const mongoose = require("mongoose");

const RequestSchema = new mongoose.Schema(
  {
    clubName:        { type: String, required: true, trim: true },
    amount:          { type: String, required: true },
    amountWei:       { type: String, required: true },
    purpose:         { type: String, required: true, trim: true },
    walletAddress:   { type: String, required: true, lowercase: true },
    status:          { type: String, enum: ["pending","approved","released","rejected"], default: "pending" },
    onChainRequestId:{ type: Number, default: null },
    requestTxHash:   { type: String, default: null },
    approveTxHash:   { type: String, default: null },
    releaseTxHash:   { type: String, default: null },
    receiptURL:      { type: String, default: null },
    receiptFilename: { type: String, default: null },
    approvedAt:      { type: Date,   default: null },
    releasedAt:      { type: Date,   default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Request", RequestSchema);
