require("dotenv").config();
const express  = require("express");
const cors     = require("cors");
const path     = require("path");
const fs       = require("fs");

const connectDB      = require("./config/db");
const blockchain     = require("./config/blockchain");
const requestRoutes  = require("./routes/requests");

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Ensure uploads folder exists ──────────────────────────────────────
const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// ── Middleware ────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(uploadsDir));

// ── Routes ────────────────────────────────────────────────────────────
app.use("/api", requestRoutes);

// ── Health check ──────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status:    "ok",
    timestamp: new Date().toISOString(),
    services:  {
      mongodb:    require("mongoose").connection.readyState === 1 ? "connected" : "disconnected",
      blockchain: blockchain.isReady() ? "connected" : "unavailable",
    },
  });
});

// ── 404 ───────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: `Route ${req.method} ${req.path} not found.` }));

// ── Error handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => res.status(500).json({ error: err.message || "Internal server error." }));

// ── Start ─────────────────────────────────────────────────────────────
async function startServer() {
  console.log("\n─────────────────────────────────────────");
  console.log("  FundChain Backend — Starting...");
  console.log("─────────────────────────────────────────\n");

  await connectDB();
  await blockchain.init();

  app.listen(PORT, () => {
    console.log(`\n✅ Server running → http://localhost:${PORT}`);
    console.log("\n  Endpoints:");
    console.log("  POST   /api/request");
    console.log("  GET    /api/requests");
    console.log("  PATCH  /api/approve");
    console.log("  PATCH  /api/release");
    console.log("  POST   /api/upload-receipt");
    console.log("  GET    /api/tx/:hash");
    console.log("  GET    /api/stats");
    console.log("  GET    /health\n");
    console.log("─────────────────────────────────────────\n");
  });
}

startServer();
module.exports = app;
