import { useState } from "react";
import RequestForm from "../components/RequestForm";

const C = { gold: "#C9A84C", goldLight: "#F5D580", goldDim: "#3d2f00", goldBg: "#1a1500", muted: "#666" };

function HashPill({ hash }) {
  if (!hash) return null;
  return (
    <span style={{ fontFamily: "monospace", fontSize: 11, color: C.gold, background: C.goldBg, border: `1px solid ${C.goldDim}`, borderRadius: 6, padding: "3px 8px" }}>
      {hash.slice(0, 10)}…{hash.slice(-8)}
    </span>
  );
}

export default function RequestPage({ wallet, onConnect }) {
  const [submitted, setSubmitted] = useState(null);

  if (submitted) {
    const req = submitted.request;
    return (
      <div style={{ maxWidth: 520, margin: "0 auto" }}>
        <div style={{ background: "#111", border: `1px solid ${C.goldDim}`, borderRadius: 16, padding: 40, textAlign: "center" }}>
          <div style={{ width: 72, height: 72, borderRadius: "50%", background: `linear-gradient(135deg, ${C.goldBg}, #2a2000)`, border: `2px solid ${C.gold}`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 32 }}>✓</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: C.gold, letterSpacing: 1, marginBottom: 8 }}>REQUEST SUBMITTED</div>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 28 }}>Recorded and awaiting admin approval.</div>
          <div style={{ background: "#0a0a0a", borderRadius: 10, padding: 16, marginBottom: 20, textAlign: "left" }}>
            {[
              ["Club",    req.clubName],
              ["Amount",  req.amount + " ETH"],
              ["Purpose", req.purpose],
              ["TX Hash", <HashPill hash={submitted.txHash || req.requestTxHash} />],
            ].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: "1px solid #111", fontSize: 13 }}>
                <span style={{ color: C.muted }}>{k}</span>
                <span style={{ color: "#f5f5f5" }}>{v}</span>
              </div>
            ))}
          </div>
          <button onClick={() => setSubmitted(null)} style={{ width: "100%", background: `linear-gradient(135deg, ${C.gold}, ${C.goldLight})`, border: "none", borderRadius: 12, padding: "14px 20px", fontSize: 15, fontWeight: 600, color: "#0a0a0a", cursor: "pointer" }}>
            Submit Another Request
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 520, margin: "0 auto" }}>
      <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: -0.5, marginBottom: 6 }}>Request Funds</div>
      <p style={{ fontSize: 14, color: C.muted, marginBottom: 28 }}>Submit a funding request for your student club. Every request is recorded on-chain.</p>

      {!wallet && (
        <div style={{ background: "#0d0d00", border: `1px solid ${C.goldDim}`, borderRadius: 10, padding: "14px 18px", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 13, color: C.gold }}>Connect your wallet to sign transactions</span>
          <button onClick={onConnect} style={{ background: C.goldBg, border: `1px solid ${C.goldDim}`, borderRadius: 8, padding: "8px 16px", color: C.gold, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
            Connect MetaMask
          </button>
        </div>
      )}

      <RequestForm wallet={wallet} onSuccess={setSubmitted} />

      {/* How it works */}
      <div style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 16, padding: 24, marginTop: 16 }}>
        <div style={{ fontSize: 11, color: "#2a2a2a", letterSpacing: 1, textTransform: "uppercase", marginBottom: 18 }}>How it works</div>
        {[["1","Submit","Saved and recorded on-chain with a unique TX hash."],["2","Admin Review","College admin reviews on the dashboard."],["3","Approval","Admin calls approveRequest() on the smart contract."],["4","Fund Release","Funds transferred to your wallet via releaseFunds()."]].map(([n, title, desc]) => (
          <div key={n} style={{ display: "flex", gap: 16, marginBottom: 16 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", flexShrink: 0, background: C.goldBg, border: `1px solid ${C.goldDim}`, display: "flex", alignItems: "center", justifyContent: "center", color: C.gold, fontSize: 12, fontWeight: 700 }}>{n}</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: "#ddd", marginBottom: 3 }}>{title}</div>
              <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.5 }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
