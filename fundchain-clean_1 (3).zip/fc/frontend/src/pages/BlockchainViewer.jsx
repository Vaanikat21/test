import TransactionViewer from "../components/TransactionViewer";

export default function BlockchainViewer({ txLog }) {
  return (
    <div>
      <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: -0.5, marginBottom: 6 }}>Tx Explorer</div>
      <p style={{ fontSize: 14, color: "#666", marginBottom: 24 }}>
        Every FundChain action generates an immutable on-chain transaction.
      </p>
      <TransactionViewer txLog={txLog} />
    </div>
  );
}
