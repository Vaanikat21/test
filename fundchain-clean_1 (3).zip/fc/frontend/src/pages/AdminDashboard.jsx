import { useState, useEffect } from "react";
import AdminTable from "../components/AdminTable";
import { getRequests, getStats } from "../services/api";

const C = { gold: "#C9A84C", goldDim: "#3d2f00", goldBg: "#1a1500", blue: "#5B9CF6", green: "#52D49B" };

export default function AdminDashboard({ showToast }) {
  const [requests, setRequests] = useState([]);
  const [stats, setStats]       = useState(null);
  const [filter, setFilter]     = useState("all");
  const [loading, setLoading]   = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getRequests();
      setRequests(data.requests || []);
      if (data.contractStats) setStats(data.contractStats);
      // Also fetch db stats
      const s = await getStats();
      if (s.contractStats) setStats(s.contractStats);
    } catch (_) {}
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = filter === "all" ? requests : requests.filter((r) => r.status === filter);
  const counts   = ["pending","approved","released"].reduce((a,s) => ({ ...a, [s]: requests.filter(r => r.status===s).length }), {});

  return (
    <div>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 28, flexWrap: "wrap", gap: 12 }}>
        <div>
          <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: -0.5, marginBottom: 6 }}>Admin Dashboard</div>
          <p style={{ fontSize: 14, color: "#666" }}>Review and manage fund requests. All actions recorded on-chain.</p>
        </div>
        <button onClick={load} disabled={loading} style={{ background: C.goldBg, border: `1px solid ${C.goldDim}`, borderRadius: 8, padding: "8px 16px", color: C.gold, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
          {loading ? "Loading..." : "↻ Refresh"}
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, marginBottom: 28 }}>
          {[
            ["Contract Balance", `${parseFloat(stats.balanceEth).toFixed(4)} ETH`, C.gold],
            ["Pending",   counts.pending  || 0, C.gold ],
            ["Approved",  counts.approved || 0, C.blue ],
            ["Released",  counts.released || 0, C.green],
          ].map(([label, value, color]) => (
            <div key={label} style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 12, padding: 18 }}>
              <div style={{ fontSize: 11, color: "#444", letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>{label}</div>
              <div style={{ fontSize: 22, fontWeight: 700, color }}>{value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Filter tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {["all","pending","approved","released"].map((f) => (
          <button key={f} onClick={() => setFilter(f)} style={{
            background: filter===f ? C.goldBg : "none",
            border: `1px solid ${filter===f ? C.goldDim : "#1e1e1e"}`,
            borderRadius: 8, padding: "6px 16px", cursor: "pointer",
            color: filter===f ? C.gold : "#666",
            fontSize: 12, fontWeight: 600, letterSpacing: 0.5, textTransform: "uppercase",
          }}>
            {f}{f!=="all" && ` (${requests.filter(r=>r.status===f).length})`}
          </button>
        ))}
      </div>

      {/* Table */}
      <div style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 16, overflow: "hidden" }}>
        <AdminTable requests={filtered} onRefresh={load} showToast={showToast} />
      </div>
    </div>
  );
}
