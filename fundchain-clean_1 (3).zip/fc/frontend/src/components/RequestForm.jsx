import { useState } from "react";
import { createRequest } from "../services/api";

const C = { gold: "#C9A84C", goldLight: "#F5D580", goldDim: "#3d2f00", goldBg: "#1a1500", muted: "#666" };

const inputStyle = {
  width: "100%", background: "#0a0a0a", border: "1px solid #222",
  borderRadius: 10, padding: "12px 16px", color: "#f5f5f5",
  fontSize: 14, outline: "none", boxSizing: "border-box",
  fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
};
const labelStyle = {
  display: "block", fontSize: 11, fontWeight: 600, color: C.muted,
  letterSpacing: 1, textTransform: "uppercase", marginBottom: 8,
};

export default function RequestForm({ wallet, onSuccess }) {
  const [form, setForm]           = useState({ clubName: "", amount: "", purpose: "", walletAddress: wallet || "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]         = useState("");

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    const { clubName, amount, purpose, walletAddress } = form;
    if (!clubName || !amount || !purpose || !walletAddress) { setError("All fields are required."); return; }
    if (isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) { setError("Enter a valid ETH amount."); return; }
    setError("");
    setSubmitting(true);
    try {
      const result = await createRequest({ ...form, amount: parseFloat(amount).toString() });
      onSuccess(result);
    } catch (e) {
      setError(e.message);
    }
    setSubmitting(false);
  };

  return (
    <div style={{ background: "#111", border: `1px solid ${C.goldDim}`, borderRadius: 16, padding: 24 }}>
      {error && (
        <div style={{ background: "#1a0000", border: "1px solid #500", borderRadius: 8, padding: "10px 14px", marginBottom: 16, color: "#f87171", fontSize: 13 }}>
          {error}
        </div>
      )}

      {[
        { id: "clubName",      label: "Club Name",              ph: "e.g. Robotics Club", type: "text"   },
        { id: "amount",        label: "Amount Requested (ETH)", ph: "e.g. 0.05",          type: "number" },
        { id: "walletAddress", label: "Club Wallet Address",    ph: "0x...",              type: "text"   },
      ].map((f) => (
        <div key={f.id} style={{ marginBottom: 18 }}>
          <label style={labelStyle}>{f.label}</label>
          <input type={f.type} placeholder={f.ph} value={form[f.id]}
            onChange={set(f.id)} style={inputStyle} />
        </div>
      ))}

      <div style={{ marginBottom: 24 }}>
        <label style={labelStyle}>Purpose / Description</label>
        <textarea placeholder="Describe what the funds will be used for..." value={form.purpose}
          onChange={set("purpose")} rows={3}
          style={{ ...inputStyle, resize: "vertical" }} />
      </div>

      <button onClick={submit} disabled={submitting} style={{
        width: "100%", background: `linear-gradient(135deg, ${C.gold}, ${C.goldLight})`,
        border: "none", borderRadius: 12, padding: "14px 20px",
        fontSize: 15, fontWeight: 600, color: "#0a0a0a", cursor: "pointer",
        opacity: submitting ? 0.7 : 1,
        fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
      }}>
        {submitting ? "Submitting..." : "Submit On-Chain Request"}
      </button>
    </div>
  );
}
