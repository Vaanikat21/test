import { useState } from "react";
import { getTransaction } from "../services/api";

const C = { gold: "#C9A84C", goldDim: "#3d2f00", goldBg: "#1a1500" };

function HashPill({ hash, color }) {
  const [copied, setCopied] = useState(false);
  if (!hash) return <span style={{ color: "#333" }}>—</span>;
  return (
    <span onClick={() => { navigator.clipboard?.writeText(hash); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
      title={hash} style={{ fontFamily: "monospace", fontSize: 11, color: color || C.gold, background: C.goldBg, border: `1px solid ${C.goldDim}`, borderRadius: 6, padding: "3px 8px", cursor: "pointer" }}>
      {hash.slice(0, 8)}…{hash.slice(-6)}{copied ? " ✓" : ""}
    </span>
  );
}

export default function TransactionViewer({ txLog }) {
  const [search, setSearch]   = useState("");
  const [txDetail, setTxDetail] = useState(null);
  const [loading, setLoading]   = useState(false);

  const typeConf = {
    DEPOSIT: { color: "#5B9CF6", icon: "⊕", label: "Deposit"      },
    REQUEST: { color: C.gold,    icon: "📋", label: "Fund Request" },
    APPROVE: { color: "#A78BFA", icon: "✅", label: "Approval"     },
    RELEASE: { color: "#52D49B", icon: "💸", label: "Fund Release" },
  };

  const filtered = (txLog || []).slice().reverse().filter((tx) =>
    !search || tx.hash?.includes(search) || (tx.clubName || "").toLowerCase().includes(search.toLowerCase())
  );

  const lookupTx = async () => {
    if (!search.startsWith("0x")) return;
    setLoading(true);
    try {
      const data = await getTransaction(search);
      setTxDetail(data);
    } catch (e) {
      alert("TX not found: " + e.message);
    }
    setLoading(false);
  };

  return (
    <div>
      {/* Search bar */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <input placeholder="Search by TX hash or club name..."
          value={search} onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && lookupTx()}
          style={{ flex: 1, background: "#0a0a0a", border: "1px solid #222", borderRadius: 10, padding: "12px 16px", color: "#f5f5f5", fontSize: 14, outline: "none", fontFamily: "inherit" }} />
        <button onClick={lookupTx} disabled={loading} style={{ background: C.gold, border: "none", borderRadius: 10, padding: "0 20px", color: "#0a0a0a", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          {loading ? "..." : "Look Up"}
        </button>
        <button onClick={() => { setSearch(""); setTxDetail(null); }} style={{ background: "#1a1500", border: "1px solid #3d2f00", borderRadius: 10, padding: "0 16px", color: C.gold, fontSize: 13, cursor: "pointer" }}>
          Clear
        </button>
      </div>

      {/* TX Detail card */}
      {txDetail && (
        <div style={{ background: "#111", border: `1px solid ${C.goldDim}`, borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: txDetail.status === "success" ? "#52D49B" : "#f87171" }} />
            <span style={{ color: txDetail.status === "success" ? "#52D49B" : "#f87171", fontWeight: 700, fontSize: 13, letterSpacing: 1 }}>
              {(txDetail.status || "").toUpperCase()}
            </span>
          </div>
          {[
            ["Hash",        <HashPill hash={txDetail.hash} />],
            ["From",        <span style={{ fontFamily: "monospace", fontSize: 12, color: "#aaa" }}>{txDetail.from}</span>],
            ["To",          <span style={{ fontFamily: "monospace", fontSize: 12, color: "#aaa" }}>{txDetail.to}</span>],
            ["Value",       `${txDetail.value} ETH`],
            ["Block",       `#${txDetail.blockNumber}`],
            ["Gas Used",    txDetail.gasUsed],
            ["Timestamp",   new Date(txDetail.timestamp).toLocaleString()],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: "1px solid #1a1a1a", fontSize: 13 }}>
              <span style={{ color: "#555" }}>{k}</span>
              <span style={{ color: "#ccc" }}>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* TX list */}
      <div style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 16, padding: 24 }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40, color: "#333" }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>⛓</div>
            <div>{txLog?.length === 0 ? "No transactions yet." : "No results."}</div>
          </div>
        ) : filtered.map((tx, i) => {
          const conf = typeConf[tx.type] || { color: "#555", icon: "•", label: tx.type };
          return (
            <div key={tx.hash} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 8px", borderBottom: i < filtered.length - 1 ? "1px solid #111" : "none" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: "#0a0a0a", border: `1px solid ${conf.color}22`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>
                  {conf.icon}
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, color: conf.color, marginBottom: 4, textTransform: "uppercase" }}>
                    {conf.label}{tx.clubName ? ` · ${tx.clubName}` : ""}
                  </div>
                  <HashPill hash={tx.hash} color={conf.color} />
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                {tx.amount && <div style={{ fontSize: 14, fontWeight: 700, color: C.gold, marginBottom: 2 }}>{tx.amount} ETH</div>}
                <div style={{ fontSize: 11, color: "#444" }}>Block #{tx.blockNumber}</div>
                <div style={{ fontSize: 10, color: "#2a2a2a" }}>{new Date(tx.timestamp).toLocaleTimeString()}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
