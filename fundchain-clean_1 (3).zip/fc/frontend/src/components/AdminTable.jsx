import { approveRequest, releaseRequest } from "../services/api";

const C = { gold: "#C9A84C", goldDim: "#3d2f00", goldBg: "#1a1500", blue: "#5B9CF6", blueBg: "#001830", blueBorder: "#003070", green: "#52D49B", greenBg: "#001a0e", greenBorder: "#004d2a" };

function StatusPill({ status }) {
  const cfg = {
    pending:  { bg: C.goldBg,  color: C.gold,  border: C.goldDim     },
    approved: { bg: C.blueBg,  color: C.blue,  border: C.blueBorder  },
    released: { bg: C.greenBg, color: C.green, border: C.greenBorder },
  }[status] || { bg: "#111", color: "#666", border: "#333" };
  return (
    <span style={{ background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`, borderRadius: 20, padding: "3px 12px", fontSize: 11, fontWeight: 700, letterSpacing: 0.8, textTransform: "uppercase" }}>
      {status}
    </span>
  );
}

function HashPill({ hash }) {
  if (!hash) return <span style={{ color: "#333" }}>—</span>;
  return (
    <span onClick={() => navigator.clipboard?.writeText(hash)} title={hash} style={{ fontFamily: "monospace", fontSize: 11, color: C.gold, background: C.goldBg, border: `1px solid ${C.goldDim}`, borderRadius: 6, padding: "3px 8px", cursor: "pointer" }}>
      {hash.slice(0, 8)}…{hash.slice(-6)}
    </span>
  );
}

export default function AdminTable({ requests, onRefresh, showToast }) {
  const handleApprove = async (req) => {
    try {
      await approveRequest(req._id);
      showToast("Approved " + req.clubName);
      onRefresh();
    } catch (e) { showToast("Failed: " + e.message); }
  };

  const handleRelease = async (req) => {
    try {
      await releaseRequest(req._id);
      showToast("Released funds to " + req.clubName);
      onRefresh();
    } catch (e) { showToast("Failed: " + e.message); }
  };

  if (requests.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: 56, color: "#333" }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>⛓</div>
        <div style={{ fontSize: 14 }}>No requests found</div>
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr style={{ borderBottom: "1px solid #1e1e1e" }}>
            {["Club", "Amount (ETH)", "Purpose", "Wallet", "Status", "TX Hash", "Actions"].map((h) => (
              <th key={h} style={{ textAlign: "left", padding: "12px 16px", color: "#444", fontWeight: 600, fontSize: 11, letterSpacing: 1, textTransform: "uppercase" }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {requests.map((req) => {
            const best = req.releaseTxHash || req.approveTxHash || req.requestTxHash;
            const amt  = parseFloat(req.amount).toFixed(4);
            const addr = req.walletAddress || "";
            return (
              <tr key={req._id} style={{ borderBottom: "1px solid #0f0f0f" }}>
                <td style={{ padding: "14px 16px", color: "#f5f5f5", fontWeight: 600 }}>{req.clubName}</td>
                <td style={{ padding: "14px 16px", color: C.gold, fontFamily: "monospace" }}>{amt}</td>
                <td style={{ padding: "14px 16px", color: "#888", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{req.purpose}</td>
                <td style={{ padding: "14px 16px", fontFamily: "monospace", fontSize: 11, color: "#444" }}>{addr ? addr.slice(0, 6) + "…" + addr.slice(-4) : "—"}</td>
                <td style={{ padding: "14px 16px" }}><StatusPill status={req.status} /></td>
                <td style={{ padding: "14px 16px" }}><HashPill hash={best} /></td>
                <td style={{ padding: "14px 16px" }}>
                  {req.status === "pending" && (
                    <button onClick={() => handleApprove(req)} style={{ background: C.blueBg, color: C.blue, border: `1px solid ${C.blueBorder}`, borderRadius: 8, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", marginRight: 6 }}>
                      Approve
                    </button>
                  )}
                  {req.status === "approved" && (
                    <button onClick={() => handleRelease(req)} style={{ background: C.greenBg, color: C.green, border: `1px solid ${C.greenBorder}`, borderRadius: 8, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                      Release 💸
                    </button>
                  )}
                  {req.status === "released" && (
                    <span style={{ color: C.green, fontSize: 12, fontWeight: 600 }}>✓ Complete</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
