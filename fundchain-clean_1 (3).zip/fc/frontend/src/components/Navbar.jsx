import { useState } from "react";
import { connectMetaMask } from "../services/blockchain";

export default function Navbar({ page, setPage }) {
  const [wallet, setWallet]       = useState(null);
  const [connecting, setConnecting] = useState(false);

  const connect = async () => {
    setConnecting(true);
    try {
      const { account } = await connectMetaMask();
      setWallet(account);
    } catch (e) {
      alert(e.message);
    }
    setConnecting(false);
  };

  const TABS = [
    { id: "request",  label: "Request Funds"   },
    { id: "admin",    label: "Admin Dashboard"  },
    { id: "explorer", label: "Tx Explorer"      },
  ];

  // ── Styles ────────────────────────────────────────────────────────
  const C = {
    gold: "#C9A84C", goldLight: "#F5D580", goldDim: "#3d2f00", goldBg: "#1a1500",
  };

  return (
    <nav style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "0 32px", height: 60,
      background: "rgba(10,10,10,0.97)", borderBottom: "1px solid #1a1a1a",
      position: "sticky", top: 0, zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8, fontSize: 16,
          background: `linear-gradient(135deg, ${C.gold}, ${C.goldLight})`,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>⛓</div>
        <span style={{ fontSize: 17, fontWeight: 600, letterSpacing: 3, color: C.gold }}>
          FUNDCHAIN
        </span>
        <span style={{
          fontSize: 9, color: "#444", border: "1px solid #222",
          borderRadius: 4, padding: "1px 6px", letterSpacing: 1,
        }}>TESTNET</span>
      </div>

      {/* Nav tabs */}
      <div style={{ display: "flex", gap: 4 }}>
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setPage(t.id)} style={{
            background: page === t.id ? C.goldBg : "none",
            border: page === t.id ? `1px solid ${C.goldDim}` : "1px solid transparent",
            borderRadius: 8, padding: "7px 16px", cursor: "pointer",
            color: page === t.id ? C.gold : "#666",
            fontSize: 13, fontWeight: 500,
            fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
            transition: "all .2s",
          }}>{t.label}</button>
        ))}
      </div>

      {/* Wallet button */}
      {wallet ? (
        <div style={{
          background: C.goldBg, border: `1px solid ${C.goldDim}`,
          borderRadius: 10, padding: "8px 16px", fontSize: 13, color: C.gold, fontWeight: 500,
        }}>
          {wallet.slice(0, 6)}…{wallet.slice(-4)}
        </div>
      ) : (
        <button onClick={connect} disabled={connecting} style={{
          background: `linear-gradient(135deg, ${C.gold}, ${C.goldLight})`,
          border: "none", borderRadius: 10, padding: "9px 20px",
          cursor: "pointer", fontSize: 13, fontWeight: 600, color: "#0a0a0a",
          fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
        }}>
          {connecting ? "Connecting..." : "Connect Wallet"}
        </button>
      )}
    </nav>
  );
}
