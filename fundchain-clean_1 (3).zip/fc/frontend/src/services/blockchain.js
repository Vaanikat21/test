import { ethers } from "ethers";
import contractABI from "../utils/contractABI.json";

const CONTRACT_ADDRESS = process.env.REACT_APP_CONTRACT_ADDRESS;

// ── Connect MetaMask and return signer + contract ─────────────────────
export async function connectMetaMask() {
  if (!window.ethereum) throw new Error("MetaMask not installed. Visit metamask.io");
  const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
  const provider = new ethers.BrowserProvider(window.ethereum);
  const signer   = await provider.getSigner();
  const contract = new ethers.Contract(CONTRACT_ADDRESS, contractABI, signer);
  return { provider, signer, contract, account: accounts[0] };
}

// ── Deposit ETH into contract (admin only) ────────────────────────────
export async function depositFunds(contract, amountEth) {
  const tx = await contract.depositFunds({ value: ethers.parseEther(amountEth.toString()) });
  const receipt = await tx.wait();
  return { txHash: tx.hash, blockNumber: receipt.blockNumber };
}

// ── Student club submits a fund request ───────────────────────────────
export async function requestFunds(contract, clubName, purpose, amountEth) {
  const amountWei = ethers.parseEther(amountEth.toString());
  const tx = await contract.requestFunds(clubName, purpose, amountWei);
  const receipt = await tx.wait();

  // Extract on-chain request ID from event logs
  const event = receipt.logs
    .map((log) => { try { return contract.interface.parseLog(log); } catch { return null; } })
    .find((e) => e && e.name === "FundRequested");

  return {
    txHash: tx.hash,
    blockNumber: receipt.blockNumber,
    onChainRequestId: event ? Number(event.args.requestId) : null,
  };
}

// ── Admin approves a request ──────────────────────────────────────────
export async function approveRequest(contract, requestId) {
  const tx = await contract.approveRequest(requestId);
  const receipt = await tx.wait();
  return { txHash: tx.hash, blockNumber: receipt.blockNumber };
}

// ── Admin releases funds to club ──────────────────────────────────────
export async function releaseFunds(contract, requestId) {
  const tx = await contract.releaseFunds(requestId);
  const receipt = await tx.wait();
  return { txHash: tx.hash, blockNumber: receipt.blockNumber };
}

// ── Fetch all requests directly from chain ────────────────────────────
export async function getAllRequests(contract) {
  const reqs = await contract.getAllRequests();
  return reqs.map((r) => ({
    id:        Number(r.id),
    requester: r.requester,
    amount:    ethers.formatEther(r.amount),
    purpose:   r.purpose,
    clubName:  r.clubName,
    approved:  r.approved,
    released:  r.released,
    timestamp: Number(r.timestamp) * 1000,
  }));
}

// ── Get contract stats ────────────────────────────────────────────────
export async function getContractStats(contract) {
  const [balance, deposited, released, pending, total] = await contract.getContractStats();
  return {
    balanceEth:   ethers.formatEther(balance),
    depositedEth: ethers.formatEther(deposited),
    releasedEth:  ethers.formatEther(released),
    pendingCount: Number(pending),
    totalCount:   Number(total),
  };
}

// ── Fetch transaction details from provider ───────────────────────────
export async function getTransaction(provider, txHash) {
  const tx      = await provider.getTransaction(txHash);
  const receipt = await provider.getTransactionReceipt(txHash);
  const block   = await provider.getBlock(receipt.blockNumber);
  return {
    hash:        tx.hash,
    from:        tx.from,
    to:          tx.to,
    value:       ethers.formatEther(tx.value),
    blockNumber: receipt.blockNumber,
    status:      receipt.status === 1 ? "success" : "failed",
    gasUsed:     receipt.gasUsed.toString(),
    timestamp:   new Date(Number(block.timestamp) * 1000).toISOString(),
  };
}
