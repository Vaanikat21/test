const BASE_URL    = process.env.REACT_APP_API_URL || "http://localhost:5000/api";
const ADMIN_SECRET = process.env.REACT_APP_ADMIN_SECRET || "fundchain_admin_2024";

async function handleResponse(res) {
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "API request failed");
  return data;
}

// ── Submit a new fund request ─────────────────────────────────────────
export async function createRequest(body) {
  return fetch(`${BASE_URL}/request`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(body),
  }).then(handleResponse);
}

// ── Get all requests (optional filters) ──────────────────────────────
export async function getRequests(params = {}) {
  const qs = new URLSearchParams(params).toString();
  return fetch(`${BASE_URL}/requests${qs ? "?" + qs : ""}`).then(handleResponse);
}

// ── Get a single request by ID ────────────────────────────────────────
export async function getRequest(id) {
  return fetch(`${BASE_URL}/requests/${id}`).then(handleResponse);
}

// ── Admin approve a request ───────────────────────────────────────────
export async function approveRequest(requestId) {
  return fetch(`${BASE_URL}/approve`, {
    method:  "PATCH",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ requestId, adminSecret: ADMIN_SECRET }),
  }).then(handleResponse);
}

// ── Admin release funds ───────────────────────────────────────────────
export async function releaseRequest(requestId) {
  return fetch(`${BASE_URL}/release`, {
    method:  "PATCH",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ requestId, adminSecret: ADMIN_SECRET }),
  }).then(handleResponse);
}

// ── Upload a receipt file ─────────────────────────────────────────────
export async function uploadReceipt(requestId, file) {
  const formData = new FormData();
  formData.append("receipt",   file);
  formData.append("requestId", requestId);
  return fetch(`${BASE_URL}/upload-receipt`, {
    method: "POST",
    body:   formData,
  }).then(handleResponse);
}

// ── Fetch transaction details via backend ─────────────────────────────
export async function getTransaction(txHash) {
  return fetch(`${BASE_URL}/tx/${txHash}`).then(handleResponse);
}

// ── Get dashboard stats ───────────────────────────────────────────────
export async function getStats() {
  return fetch(`${BASE_URL}/stats`).then(handleResponse);
}
