import { useState, useCallback } from "react";
import Navbar           from "./components/Navbar";
import RequestPage      from "./pages/RequestPage";
import AdminDashboard   from "./pages/AdminDashboard";
import BlockchainViewer from "./pages/BlockchainViewer";
import { connectMetaMask } from "./services/blockchain";

export default function App() {
  const [page, setPage]   = useState("request");
  const [wallet, setWallet] = useState(null);
  const [txLog, setTxLog]   = useState([]);
  const [toast, setToast]   = useState({ msg: "", show: false });

  const showToast = useCallback((msg) => {
    setToast({ msg, show: true });
    setTimeout(() => setToast((t) => ({ ...t, show: false })), 3500);
  }, []);

  const connectWallet = useCallback(async () => {
    try {
      const { account } = await connectMetaMask();
      setWallet(account);
      showToast("Wallet connected: " + account.slice(0, 10) + "...");
    } catch (e) {
      showToast("Connection failed: " + e.message);
    }
  }, [showToast]);

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0a", color: "#f5f5f5", fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        input, textarea, button { font-family: inherit !important; }
        input:focus, textarea:focus { border-color: #C9A84C !important; outline: none; }
        button:hover { opacity: 0.85; }
        ::placeholder { color: #2a2a2a !important; }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: #0a0a0a; }
        ::-webkit-scrollbar-thumb { background: #222; border-radius: 3px; }
        tr:hover td { background: #0d0d0d; }
      `}</style>

      <Navbar page={page} setPage={setPage} wallet={wallet} onConnect={connectWallet} />

      <main style={{ maxWidth: 960, margin: "0 auto", padding: "40px 24px" }}>
        {page === "request"  && <RequestPage      wallet={wallet} onConnect={connectWallet} />}
        {page === "admin"    && <AdminDashboard   showToast={showToast} />}
        {page === "explorer" && <BlockchainViewer txLog={txLog} />}
      </main>

      {/* Toast notification */}
      <div style={{
        position: "fixed", bottom: 24, right: 24,
        background: "#111", border: "1px solid #C9A84C",
        borderRadius: 12, padding: "14px 20px",
        fontSize: 13, color: "#C9A84C", maxWidth: 320, zIndex: 999,
        transform: toast.show ? "none" : "translateY(80px)",
        opacity: toast.show ? 1 : 0, transition: "all .3s",
      }}>
        {toast.msg}
      </div>
    </div>
  );
}
