const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

/**
 * Deploy FundDistribution contract and save the address + ABI
 * for the backend and frontend to use.
 */
async function main() {
  console.log("─────────────────────────────────────────");
  console.log("  FundChain – Smart Contract Deployment");
  console.log("─────────────────────────────────────────\n");

  // Get the deployer account
  const [deployer] = await ethers.getSigners();
  const balance = await ethers.provider.getBalance(deployer.address);

  console.log(`Deployer address : ${deployer.address}`);
  console.log(`Deployer balance : ${ethers.formatEther(balance)} ETH\n`);

  if (balance === 0n) {
    console.error("⚠  Deployer has 0 ETH. Fund the account before deploying.");
    process.exit(1);
  }

  // Deploy the contract
  console.log("Deploying FundDistribution...");
  const FundDistribution = await ethers.getContractFactory("FundDistribution");
  const contract = await FundDistribution.deploy();
  await contract.waitForDeployment();

  const contractAddress = await contract.getAddress();
  console.log(`✅ FundDistribution deployed to: ${contractAddress}\n`);

  // ── Optional: deposit initial funds for demo (0.1 ETH)
  if (process.env.DEPOSIT_ON_DEPLOY === "true") {
    console.log("Depositing 0.1 ETH for demo...");
    const depositTx = await contract.depositFunds({
      value: ethers.parseEther("0.1"),
    });
    await depositTx.wait();
    console.log(`✅ Deposited 0.1 ETH — tx: ${depositTx.hash}\n`);
  }

  // ── Save deployment info for backend + frontend
  const artifact = await hre.artifacts.readArtifact("FundDistribution");
  const deploymentInfo = {
    contractAddress,
    abi: artifact.abi,
    network: hre.network.name,
    deployedAt: new Date().toISOString(),
    deployer: deployer.address,
  };

  // Write to smart-contract/deployment.json
  const outPath = path.join(__dirname, "../deployment.json");
  fs.writeFileSync(outPath, JSON.stringify(deploymentInfo, null, 2));
  console.log(`📄 Deployment info saved to: ${outPath}`);

  // Also update .env files automatically
  const backendEnvPath = path.join(__dirname, "../../backend/.env");
  const frontendEnvPath = path.join(__dirname, "../../frontend/.env");

  [backendEnvPath, frontendEnvPath].forEach((envPath) => {
    if (fs.existsSync(envPath)) {
      let content = fs.readFileSync(envPath, "utf8");
      // Replace placeholder or old address
      content = content
        .replace(/CONTRACT_ADDRESS=.*/,        `CONTRACT_ADDRESS=${contractAddress}`)
        .replace(/REACT_APP_CONTRACT_ADDRESS=.*/, `REACT_APP_CONTRACT_ADDRESS=${contractAddress}`);
      fs.writeFileSync(envPath, content);
      console.log(`📄 Updated contract address in: ${envPath}`);
    }
  });

  fs.mkdirSync(path.dirname(backendAbiPath), { recursive: true });
  fs.mkdirSync(path.dirname(frontendAbiPath), { recursive: true });

  fs.writeFileSync(backendAbiPath, JSON.stringify(artifact.abi, null, 2));
  fs.writeFileSync(frontendAbiPath, JSON.stringify(artifact.abi, null, 2));

  console.log(`📄 ABI copied to backend: ${backendAbiPath}`);
  console.log(`📄 ABI copied to frontend: ${frontendAbiPath}`);

  console.log("\n─────────────────────────────────────────");
  console.log("  DEPLOYMENT COMPLETE");
  console.log("─────────────────────────────────────────");
  console.log(`  Contract : ${contractAddress}`);
  console.log(`  Network  : ${hre.network.name}`);
  console.log("─────────────────────────────────────────\n");
  console.log("Next steps:");
  console.log("  1. Copy CONTRACT_ADDRESS to backend/.env and frontend/.env");
  console.log(`     CONTRACT_ADDRESS=${contractAddress}`);
  console.log("  2. Start the backend: cd ../backend && npm start");
  console.log("  3. Start the frontend: cd ../frontend && npm start\n");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Deployment failed:", error);
    process.exit(1);
  });
