// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title FundDistribution
 * @dev FundChain – Transparent College Fund Distribution Platform
 * @notice Smart contract for managing student club fund requests with full on-chain transparency
 */
contract FundDistribution {

    // ─────────────────────────────────────────────────────────────
    //  STATE VARIABLES
    // ─────────────────────────────────────────────────────────────

    address public admin;           // Contract deployer / college admin
    uint256 public totalDeposited;  // Total ETH deposited by admin
    uint256 public totalReleased;   // Total ETH released to clubs
    uint256 public requestCount;    // Auto-incrementing request ID counter

    // ─────────────────────────────────────────────────────────────
    //  STRUCTS
    // ─────────────────────────────────────────────────────────────

    /**
     * @dev Represents a single fund request from a student club
     */
    struct Request {
        uint256 id;             // Unique identifier
        address requester;      // Wallet address of the club representative
        uint256 amount;         // Requested amount in Wei
        string purpose;         // Description / reason for funds
        bool approved;          // Admin approval status
        bool released;          // Whether funds have been sent
        uint256 timestamp;      // Block timestamp when request was created
        string clubName;        // Name of the student club
    }

    // ─────────────────────────────────────────────────────────────
    //  MAPPINGS & ARRAYS
    // ─────────────────────────────────────────────────────────────

    mapping(uint256 => Request) public requests;    // requestId => Request
    uint256[] public requestIds;                     // Array of all request IDs (for enumeration)

    // ─────────────────────────────────────────────────────────────
    //  EVENTS – every important action emits an event for transparency
    // ─────────────────────────────────────────────────────────────

    event FundsDeposited(address indexed admin, uint256 amount, uint256 timestamp);
    event FundRequested(uint256 indexed requestId, address indexed requester, string clubName, uint256 amount, string purpose);
    event RequestApproved(uint256 indexed requestId, address indexed approvedBy, uint256 timestamp);
    event FundsReleased(uint256 indexed requestId, address indexed recipient, uint256 amount, uint256 timestamp);

    // ─────────────────────────────────────────────────────────────
    //  MODIFIERS
    // ─────────────────────────────────────────────────────────────

    /// @dev Restricts function to only the admin address
    modifier onlyAdmin() {
        require(msg.sender == admin, "FundDistribution: caller is not the admin");
        _;
    }

    /// @dev Validates a request exists
    modifier requestExists(uint256 requestId) {
        require(requestId > 0 && requestId <= requestCount, "FundDistribution: request does not exist");
        _;
    }

    // ─────────────────────────────────────────────────────────────
    //  CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────

    /**
     * @dev Sets the deployer as admin
     */
    constructor() {
        admin = msg.sender;
        requestCount = 0;
    }

    // ─────────────────────────────────────────────────────────────
    //  FUNCTIONS
    // ─────────────────────────────────────────────────────────────

    /**
     * @notice Admin deposits ETH into the contract to fund student clubs
     * @dev Must send ETH with this call (payable). Only admin can call.
     */
    function depositFunds() external payable onlyAdmin {
        require(msg.value > 0, "FundDistribution: deposit amount must be greater than 0");
        totalDeposited += msg.value;
        emit FundsDeposited(msg.sender, msg.value, block.timestamp);
    }

    /**
     * @notice Student club submits a fund request
     * @param clubName The name of the student club making the request
     * @param purpose  A description of why the funds are needed
     * @param amount   The amount of ETH requested (in Wei)
     * @return requestId The ID of the newly created request
     */
    function requestFunds(
        string calldata clubName,
        string calldata purpose,
        uint256 amount
    ) external returns (uint256) {
        require(bytes(purpose).length > 0,  "FundDistribution: purpose cannot be empty");
        require(bytes(clubName).length > 0, "FundDistribution: club name cannot be empty");
        require(amount > 0,                  "FundDistribution: amount must be greater than 0");
        require(amount <= address(this).balance, "FundDistribution: requested amount exceeds contract balance");

        requestCount++;
        uint256 newId = requestCount;

        requests[newId] = Request({
            id:        newId,
            requester: msg.sender,
            amount:    amount,
            purpose:   purpose,
            approved:  false,
            released:  false,
            timestamp: block.timestamp,
            clubName:  clubName
        });

        requestIds.push(newId);

        emit FundRequested(newId, msg.sender, clubName, amount, purpose);
        return newId;
    }

    /**
     * @notice Admin approves a pending fund request
     * @dev Sets approved = true. Funds are NOT released here – use releaseFunds().
     * @param requestId The ID of the request to approve
     */
    function approveRequest(uint256 requestId)
        external
        onlyAdmin
        requestExists(requestId)
    {
        Request storage req = requests[requestId];
        require(!req.approved, "FundDistribution: request already approved");
        require(!req.released, "FundDistribution: funds already released");

        req.approved = true;

        emit RequestApproved(requestId, msg.sender, block.timestamp);
    }

    /**
     * @notice Releases approved funds to the requesting club wallet
     * @dev Requires prior approval. Transfers ETH directly to requester address.
     * @param requestId The ID of the approved request to release funds for
     */
    function releaseFunds(uint256 requestId)
        external
        onlyAdmin
        requestExists(requestId)
    {
        Request storage req = requests[requestId];
        require(req.approved,             "FundDistribution: request not yet approved");
        require(!req.released,            "FundDistribution: funds already released");
        require(address(this).balance >= req.amount, "FundDistribution: insufficient contract balance");

        req.released = true;
        totalReleased += req.amount;

        // Transfer ETH to the requesting club's wallet
        (bool success, ) = payable(req.requester).call{value: req.amount}("");
        require(success, "FundDistribution: ETH transfer failed");

        emit FundsReleased(requestId, req.requester, req.amount, block.timestamp);
    }

    /**
     * @notice Returns all fund requests (for frontend display)
     * @return An array of all Request structs
     */
    function getAllRequests() external view returns (Request[] memory) {
        Request[] memory allRequests = new Request[](requestIds.length);
        for (uint256 i = 0; i < requestIds.length; i++) {
            allRequests[i] = requests[requestIds[i]];
        }
        return allRequests;
    }

    /**
     * @notice Returns a single request by ID
     * @param requestId The request ID to fetch
     */
    function getRequest(uint256 requestId)
        external
        view
        requestExists(requestId)
        returns (Request memory)
    {
        return requests[requestId];
    }

    /**
     * @notice Returns the current ETH balance held in the contract
     */
    function getContractBalance() external view returns (uint256) {
        return address(this).balance;
    }

    /**
     * @notice Returns a summary of contract state for the admin dashboard
     */
    function getContractStats() external view returns (
        uint256 balance,
        uint256 deposited,
        uint256 released,
        uint256 pendingCount,
        uint256 totalCount
    ) {
        balance = address(this).balance;
        deposited = totalDeposited;
        released = totalReleased;
        totalCount = requestCount;

        uint256 pending = 0;
        for (uint256 i = 0; i < requestIds.length; i++) {
            if (!requests[requestIds[i]].approved) {
                pending++;
            }
        }
        pendingCount = pending;
    }
}
