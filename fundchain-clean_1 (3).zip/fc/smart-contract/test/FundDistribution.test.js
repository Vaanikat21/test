const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("FundDistribution", function () {
  let contract;
  let admin;
  let club1;
  let club2;

  const ONE_ETH = ethers.parseEther("1.0");
  const HALF_ETH = ethers.parseEther("0.5");
  const QUARTER_ETH = ethers.parseEther("0.25");

  beforeEach(async function () {
    [admin, club1, club2] = await ethers.getSigners();
    const FundDistribution = await ethers.getContractFactory("FundDistribution");
    contract = await FundDistribution.connect(admin).deploy();
    await contract.waitForDeployment();
  });

  describe("Deployment", function () {
    it("Should set the deployer as admin", async function () {
      expect(await contract.admin()).to.equal(admin.address);
    });

    it("Should start with 0 balance", async function () {
      expect(await contract.getContractBalance()).to.equal(0n);
    });
  });

  describe("depositFunds", function () {
    it("Should allow admin to deposit funds", async function () {
      await contract.connect(admin).depositFunds({ value: ONE_ETH });
      expect(await contract.getContractBalance()).to.equal(ONE_ETH);
    });

    it("Should reject deposits from non-admin", async function () {
      await expect(
        contract.connect(club1).depositFunds({ value: ONE_ETH })
      ).to.be.revertedWith("FundDistribution: caller is not the admin");
    });

    it("Should emit FundsDeposited event", async function () {
      await expect(contract.connect(admin).depositFunds({ value: ONE_ETH }))
        .to.emit(contract, "FundsDeposited")
        .withArgs(admin.address, ONE_ETH, anyValue);
    });
  });

  describe("requestFunds", function () {
    beforeEach(async function () {
      await contract.connect(admin).depositFunds({ value: ONE_ETH });
    });

    it("Should allow a club to submit a request", async function () {
      await contract.connect(club1).requestFunds("Tech Club", "Annual hackathon", QUARTER_ETH);
      const reqs = await contract.getAllRequests();
      expect(reqs.length).to.equal(1);
      expect(reqs[0].clubName).to.equal("Tech Club");
      expect(reqs[0].approved).to.be.false;
    });

    it("Should emit FundRequested event", async function () {
      await expect(
        contract.connect(club1).requestFunds("Tech Club", "Hackathon", QUARTER_ETH)
      ).to.emit(contract, "FundRequested");
    });

    it("Should reject empty purpose", async function () {
      await expect(
        contract.connect(club1).requestFunds("Tech Club", "", QUARTER_ETH)
      ).to.be.revertedWith("FundDistribution: purpose cannot be empty");
    });
  });

  describe("approveRequest", function () {
    beforeEach(async function () {
      await contract.connect(admin).depositFunds({ value: ONE_ETH });
      await contract.connect(club1).requestFunds("Drama Club", "Stage equipment", QUARTER_ETH);
    });

    it("Should allow admin to approve a request", async function () {
      await contract.connect(admin).approveRequest(1);
      const req = await contract.getRequest(1);
      expect(req.approved).to.be.true;
    });

    it("Should reject double approval", async function () {
      await contract.connect(admin).approveRequest(1);
      await expect(
        contract.connect(admin).approveRequest(1)
      ).to.be.revertedWith("FundDistribution: request already approved");
    });
  });

  describe("releaseFunds", function () {
    beforeEach(async function () {
      await contract.connect(admin).depositFunds({ value: ONE_ETH });
      await contract.connect(club1).requestFunds("Sports Club", "Equipment purchase", QUARTER_ETH);
      await contract.connect(admin).approveRequest(1);
    });

    it("Should release funds to the requester", async function () {
      const balanceBefore = await ethers.provider.getBalance(club1.address);
      await contract.connect(admin).releaseFunds(1);
      const balanceAfter = await ethers.provider.getBalance(club1.address);
      expect(balanceAfter - balanceBefore).to.equal(QUARTER_ETH);
    });

    it("Should mark request as released", async function () {
      await contract.connect(admin).releaseFunds(1);
      const req = await contract.getRequest(1);
      expect(req.released).to.be.true;
    });

    it("Should reject releasing unapproved request", async function () {
      await contract.connect(club2).requestFunds("Art Club", "Paint supplies", QUARTER_ETH);
      await expect(
        contract.connect(admin).releaseFunds(2)
      ).to.be.revertedWith("FundDistribution: request not yet approved");
    });
  });
});

// Chai helper
const anyValue = () => true;
