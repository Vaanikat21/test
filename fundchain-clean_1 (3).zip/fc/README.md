# ⛓ FundChain – Transparent College Fund Distribution Platform

Blockchain-powered fund distribution system for student clubs.
Every request, approval, and release is recorded on-chain with a TX hash.

---

## 🗂 Project Structure

```
fundchain/
├── frontend/
│   ├── public/
│   └── src/
│       ├── components/
│       │   ├── Navbar.jsx              ← Top navigation + wallet connect
│       │   ├── RequestForm.jsx         ← Fund request form
│       │   ├── AdminTable.jsx          ← Requests table with actions
│       │   └── TransactionViewer.jsx   ← TX hash explorer
│       ├── pages/
│       │   ├── RequestPage.jsx         ← Student request page
│       │   ├── AdminDashboard.jsx      ← Admin review page
│       │   └── BlockchainViewer.jsx    ← TX explorer page
│       ├── services/
│       │   ├── api.js                  ← All backend API calls
│       │   └── blockchain.js           ← All ethers.js interactions
│       ├── App.jsx                     ← Root component
│       └── index.js                    ← Entry point
│
├── backend/
│   ├── server.js                       ← Express entry point
│   ├── routes/
│   │   └── requests.js                 ← Route definitions only
│   ├── controllers/
│   │   └── requestController.js        ← All business logic
│   ├── models/
│   │   └── Request.js                  ← MongoDB schema
│   ├── middleware/
│   │   └── upload.js                   ← Multer file uploads
│   └── config/
│       ├── db.js                       ← MongoDB connection
│       ├── blockchain.js               ← ethers.js service
│       └── contractABI.json            ← Auto-generated after deploy
│
├── smart-contract/
│   ├── contracts/
│   │   └── FundDistribution.sol        ← Solidity contract
│   ├── scripts/
│   │   └── deploy.js                   ← Deployment script
│   ├── test/
│   │   └── FundDistribution.test.js    ← Contract tests
│   └── hardhat.config.js
│
├── database/
│   └── mongo-schema.md
│
└── README.md
```

---

## 🚀 How to Run

### Terminal 1 — Start Blockchain
```bash
cd smart-contract
npm install
npx hardhat node
```
Keep this open. Copy the **Account #0 Private Key** from the output.

---

### Terminal 2 — Deploy Smart Contract
```bash
cd smart-contract
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
```
Copy the **Contract Address** printed in the output.

---

### Terminal 3 — Start Backend
```bash
cd backend
npm install
node server.js
```
Make sure `backend/.env` has the correct `CONTRACT_ADDRESS` and `ADMIN_PRIVATE_KEY`.

---

### Terminal 4 — Start Frontend
```bash
cd frontend
npm install
npm start
```
Opens at **http://localhost:3000**

---

## 🦊 MetaMask Setup
| Field        | Value                    |
|-------------|--------------------------|
| Network Name | Hardhat Local            |
| RPC URL      | http://127.0.0.1:8545    |
| Chain ID     | 31337                    |
| Currency     | ETH                      |

Import **Account #0 Private Key** → you get 10,000 test ETH.

---

## 📡 API Endpoints
| Method | Endpoint             | Description          |
|--------|---------------------|----------------------|
| POST   | /api/request        | Submit fund request  |
| GET    | /api/requests       | List all requests    |
| PATCH  | /api/approve        | Approve request      |
| PATCH  | /api/release        | Release funds        |
| POST   | /api/upload-receipt | Upload receipt       |
| GET    | /api/tx/:hash       | Get TX details       |
| GET    | /api/stats          | Dashboard stats      |
| GET    | /health             | Health check         |

---

## ⛓ Smart Contract Functions
```solidity
depositFunds()                                    // Admin deposits ETH
requestFunds(clubName, purpose, amount)           // Club submits request
approveRequest(requestId)                         // Admin approves
releaseFunds(requestId)                           // Admin releases ETH
getAllRequests()                                   // Read all requests
getContractStats()                                // Dashboard stats
```

---

## 🎬 Demo Flow
1. Admin deposits ETH → `depositFunds()` → TX Hash
2. Club submits request → `requestFunds()` → TX Hash
3. Admin approves → `approveRequest()` → TX Hash
4. Club uploads receipt → `/api/upload-receipt`
5. Admin releases funds → `releaseFunds()` → ETH sent to club wallet
6. All TX hashes visible in **Tx Explorer** tab

---

*FundChain — Transparent, auditable, corruption-resistant college fund distribution.*
